<template>
  <div id="ParkingDetails">
	
	<div id="carDetails">
   	<div>
     <input type = "text" placeholder = "Enter Car Number" v-model = "carNumber"/>
     <button
        v-on:click="checkAvailability"
        class = "button"
        v-bind:disabled="this.carNumber === '' ">
        Check Availability
     </button>
     </div>
     <span :class="this.messageType ==='success' ? 'sucess-message' : 'error-message'">{{this.showMessage}}</span>
   </div>
   
   <div id='parkingTableData'>
   <table id="parkingTable" align="center">
      <thead>
        <tr>
          <th>Details (CarNumber | Color | SlotNumber)</th>
        </tr>
      </thead>
      <tbody v-for="row in carDetailsTable">
        <tr>
          <td><a href="#" @click="showDialogBox(row.id)">{{row.slot}}</a></td>
        </tr>
      </tbody>
    </table>
   </div>
   
  </div>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import Vue from "vue"
import VueSimpleAlert from "vue-simple-alert";

Vue.use(VueSimpleAlert)

export default {
  name: 'ParkingDetails',
  data () {
  	return {
    	parkingNumber:15,
    	carNumber:'',
        showMessage: '',
        messageType:'',
        colors:['Black','White','Blue','Red'],
        carColor:'',
        carDetailsTable:[],
        availableSlots:[]
	}
  },
  computed: mapState({
    slotNumber: state => state.slotNumber
  }),
  methods: {
   	...mapActions([
    	'getAvailableSlot'
  	]),
  	checkAvailability:function () {
  	   let slotNumber=this.$store.state.slotNumber;
  		if( slotNumber == 16 && this.availableSlots.length == 0){
         	this.showMessage = 'Slot is unavailable....';
         	this.messageType='error';
      	}
      	else {
         	this.messageType='success';
         	let color = this.randomColors();
            if(this.availableSlots && this.availableSlots.length == 0){
            	this.showMessage = "Slot is booked & Token Number is " +slotNumber;
            	let data= this.carNumber + ' | ' + color + ' | ' + slotNumber
            	this.carDetailsTable.push({id:slotNumber,slot:data});
         		this.getAvailableSlot();
         	}else{
         	  	this.availableSlots.sort(function(a, b){return a-b});
         	  	slotNumber=this.availableSlots.shift();
         	  	this.showMessage = "Slot is booked & Token Number is " +slotNumber;
            	let data= this.carNumber + ' | ' + color + ' | ' + slotNumber
            	this.carDetailsTable.push({id:slotNumber,slot:data});
         	}
            this.carNumber='';
      }
  	},
  	randomColors() { 
        return this.colors[Math.floor(Math.random() * this.colors.length)];
    },
    showDialogBox(id) {
          this.$confirm('Do you want to leave') 
          .then(() => {
          	console.log('clicked on ok');
          	this.availableSlots.push(id); 
          	let filteredData = this.carDetailsTable.filter(e => e.id !== id);
          	this.carDetailsTable = filteredData;
          });
    }
  
  }
}
</script>

<style>
.sucess-message{
	color:green;
	font-size:small;
}
.error-message{
	color:red;
	font-size:small;
}
.button{
	cursor: pointer;
    padding: 4px 16px;
    verticalAlign: middle;
    margin: 14px;
}
table, th, td {
  border: 0.1px solid #ccc;
}
input{
	border-radius: 4px;
    padding: 4px;
    border: 1px solid #000;
}
#carDetails{
  margin-left:18px;	
}
</style>