<template>
  <div id="app">
    <h1>Multi Storey Parking</h1>
    <ParkingDetails/>
  </div>
</template>

<script>
import ParkingDetails from './ParkingDetails.vue';
import store from './store'

export default {
  name: 'app',
  components: { ParkingDetails },
  store
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}

h1, h2 {
  font-weight: normal;
}
</style>
