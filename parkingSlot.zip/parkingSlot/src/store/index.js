import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    slotNumber: 1
  },
  mutations: {
    getAvailableSlot (state) {
      state.slotNumber++
    }
  },
  actions: {
    getAvailableSlot ({ commit }) {
       commit('getAvailableSlot')
    }
  }
})