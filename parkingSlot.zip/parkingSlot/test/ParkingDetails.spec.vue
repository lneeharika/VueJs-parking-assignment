import { mount } from '@vue/test-utils'
import ParkingDetails from './src/ParkingDetails'

const wrapper = mount(ParkingDetails)

const vm = wrapper.vm


console.log(wrapper)